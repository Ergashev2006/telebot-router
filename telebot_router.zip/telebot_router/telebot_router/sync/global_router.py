from typing import List, Callable, Dict, Any
import logging
from .router import Router

logger = logging.getLogger(__name__)

class GlobalRouter:
    """
    Global Sync TeleBot router - for all sync bots
    """
    
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(self):
        if not self._initialized:
            self.router = Router("global_sync")
            self.registered_bots = set()
            self._initialized = True
            logger.info("🌍 Sync GlobalRouter has started")
    
    def message_handler(self, commands=None, func=None, content_types=None, **kwargs):
        """Global sync message handler decorator"""
        def decorator(handler: Callable):
            self.router.message_handler(
                commands=commands, func=func, content_types=content_types, **kwargs
            )(handler)
            logger.info(f"🌍 Added global sync message handler: {handler.__name__}")
            return handler
        return decorator
    
    def callback_query_handler(self, func=None, **kwargs):
        """Global sync callback handler decorator"""
        def decorator(handler: Callable):
            self.router.callback_query_handler(func=func, **kwargs)(handler)
            logger.info(f"🌍 Added global sync callback handler: {handler.__name__}")
            return handler
        return decorator
    
    def include_router(self, router: Router):
        """Adding another sync router to the global"""
        self.router.include_router(router)
        logger.info(f"📥 Sync Router '{router.name}' added to global")
    
    def register_bot(self, bot):
        """Sync bot global router registration"""
        bot_id = id(bot)
        if bot_id in self.registered_bots:
            logger.warning(f"⚠️ Sync Bot {bot_id} already registered")
            return
        
        self.router.register(bot)
        self.registered_bots.add(bot_id)
        logger.info(f"🤖 Sync bot registered global router")
    
    def get_stats(self):
        """Global sync router statisticsi"""
        handler_stats = self.router.get_handler_count()
        return {
            'total_bots': len(self.registered_bots),
            'handlers': handler_stats,
            'global_handlers': {
                'message_handlers': len(self.router.message_handlers),
                'callback_handlers': len(self.router.callback_handlers)
            }
        }

# Global sync router instance
_sync_global_router = GlobalRouter()

# Global decorators
def message_handler(commands=None, func=None, content_types=None, **kwargs):
    """Global sync message handler decorator"""
    return _sync_global_router.message_handler(
        commands=commands, func=func, content_types=content_types, **kwargs
    )

def callback_handler(func=None, **kwargs):
    """Global sync callback handler decorator"""
    return _sync_global_router.callback_query_handler(func=func, **kwargs)

# Bot registration
def register_sync_bot(bot):
    """Sync bot global router registration"""
    return _sync_global_router.register_bot(bot)

# Getting statistics
def get_sync_global_stats():
    """Get global sync statistics"""
    return _sync_global_router.get_stats()

# Add a router
def include_sync_router(router: Router):
    """Add a sync router"""
    return _sync_global_router.include_router(router)