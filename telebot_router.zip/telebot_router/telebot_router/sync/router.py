import telebot
from typing import List, Callable, Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

class Router:
    """
    Router for Sync TeleBot
    """
    
    def __init__(self, name: str = ""):
        self.name = name
        self.message_handlers = []
        self.callback_handlers = []
        logger.info(f"🔄 Sync Router '{name}' created")
    
    def message_handler(self, commands=None, func=None, content_types=None, **kwargs):
        """Sync message handler decorator"""
        def decorator(handler: Callable):
            self.message_handlers.append({
                'handler': handler,
                'commands': commands,
                'func': func,
                'content_types': content_types or ['text'],
                **kwargs
            })
            logger.debug(f"📨 Added message handler to Sync router: {handler.__name__}")
            return handler
        return decorator
    
    def callback_query_handler(self, func=None, **kwargs):
        """Sync callback handler decorator"""
        def decorator(handler: Callable):
            self.callback_handlers.append({
                'handler': handler,
                'func': func,
                **kwargs
            })
            logger.debug(f"🔄 Added callback handler to Sync router: {handler.__name__}")
            return handler
        return decorator
    
    def include_router(self, router: 'Router'):
        """Add another sync router"""
        self.message_handlers.extend(router.message_handlers)
        self.callback_handlers.extend(router.callback_handlers)
        logger.info(f"📥 Sync Router '{router.name}' added")
    
    def register(self, bot: TeleBot):
        """Connecting handlers to the Sync bot"""
        self._register_message_handlers(bot)
        self._register_callback_handlers(bot)
        logger.info(f"🤖 Sync router {len(self.message_handlers)} message, {len(self.callback_handlers)} callback handler connected")
    
    def _register_message_handlers(self, bot: TeleBot):
        """Registering sync message handlers"""
        for handler_data in self.message_handlers:
            handler = handler_data['handler']
            commands = handler_data.get('commands')
            func = handler_data.get('func')
            content_types = handler_data.get('content_types')
            
            wrapper = self._create_sync_wrapper(handler, bot, func)
            
            if commands and func:
                bot.message_handler(commands=commands, func=wrapper)(wrapper)
            elif commands:
                bot.message_handler(commands=commands)(wrapper)
            elif func:
                bot.message_handler(func=wrapper)(wrapper)
            else:
                bot.message_handler(content_types=content_types)(wrapper)
    
    def _register_callback_handlers(self, bot: TeleBot):
        """Registering sync callback handlers"""
        for handler_data in self.callback_handlers:
            handler = handler_data['handler']
            func = handler_data.get('func')
            
            wrapper = self._create_sync_callback_wrapper(handler, bot, func)
            
            if func:
                bot.callback_query_handler(func=wrapper)(wrapper)
            else:
                bot.callback_query_handler()(wrapper)
    
    def _create_sync_wrapper(self, handler: Callable, bot: TeleBot, filter_func: Optional[Callable]):
        """Sync message handler wrapper"""
        has_bot_param = 'bot' in handler.__code__.co_varnames
        
        def wrapper(message, *args, **kwargs):
            if filter_func and not filter_func(message):
                return
            try:
                if has_bot_param:
                    return handler(message, bot=bot, *args, **kwargs)
                else:
                    return handler(message, *args, **kwargs)
            except Exception as e:
                logger.error(f"❌  error {handler.__name__} - {e}")
                raise
        
        wrapper.__name__ = f"sync_wrapped_{handler.__name__}"
        return wrapper
    
    def _create_sync_callback_wrapper(self, handler: Callable, bot: TeleBot, filter_func: Optional[Callable]):
        """Sync callback handler wrapper"""
        has_bot_param = 'bot' in handler.__code__.co_varnames
        
        def wrapper(call, *args, **kwargs):
            if filter_func and not filter_func(call):
                return
            try:
                if has_bot_param:
                    return handler(call, bot=bot, *args, **kwargs)
                else:
                    return handler(call, *args, **kwargs)
            except Exception as e:
                logger.error(f"❌ Error: {handler.__name__} - {e}")
                raise
        
        wrapper.__name__ = f"sync_callback_wrapped_{handler.__name__}"
        return wrapper
    
    def get_handler_count(self):
        """Number of Handlers"""
        return {
            'message_handlers': len(self.message_handlers),
            'callback_handlers': len(self.callback_handlers)
        }
    
    def clear_handlers(self):
        """Cleaning Handlers"""
        self.message_handlers.clear()
        self.callback_handlers.clear()
        logger.info("🧹 Sync router handlers cleaned up")